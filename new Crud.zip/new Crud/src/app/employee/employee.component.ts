import { AfterViewInit, Component, OnInit, ViewChild } from '@angular/core';
import { MatPaginator } from '@angular/material/paginator';
import { MatTableDataSource } from '@angular/material/table';
import { Router } from '@angular/router';
import { EmployeeService } from './employee.service';
import { MatSort } from '@angular/material/sort';
import { FormControl, FormGroup, Validators } from '@angular/forms';

@Component({
  selector: 'app-employee',
  templateUrl: './employee.component.html',
  styleUrls: ['./employee.component.css']
})
export class EmployeeComponent implements OnInit, AfterViewInit {
  employeesList =new MatTableDataSource()
  @ViewChild(MatPaginator) paginator: MatPaginator;
  @ViewChild(MatSort) sort: MatSort;
  pageIndex = 0;
  pageSize = 10;
  totalRecords = 0;
  employeeForm:FormGroup
  formOpen=false
  displayedColumns: string[] = ['id','name', 'country',  'action']; 
  constructor(private _service: EmployeeService, private router: Router) { }

  ngOnInit(): void {
    this.getDetails()
    this.employeeForm = new FormGroup({
      id: new FormControl(''),
      name: new FormControl('', [Validators.required]),
      country: new FormControl('', [Validators.required,Validators.minLength(3)]),
       
    }) 
  }
  getDetails() {
    const data:any = this._service. getEmployeesList()
    this.employeesList = new MatTableDataSource(data)
    //console.log(this.employeesList)
   
  }

  open(type?, content?) {
    this.formOpen=true
    if (type) { 
    this.employeeForm.reset() 
    }
    else { 
      this.employeeForm.patchValue(content) 
    }
  }
  getEmployeeId(){
    if(this.employeeForm.value.id) 
      return this.employeeForm.value.id
    else return 0
  }
  onSubmit() {
    if (this.employeeForm.valid) {
     if(this.getEmployeeId()>0){
       this._service.updateEmployee(this.employeeForm.value)
     }      
     else{
       this._service.saveEmployee(this.employeeForm.value)
     }
     let data = JSON.stringify(this.employeeForm.value)
     this.router.navigate(['view',btoa(data)])
      this.employeeForm.reset()
    }
    
  }
  back(){
    this.formOpen=false
  }
  openDelete(data) {
    this._service.deleteEmployee(data.id)
    this.getDetails()
  }
  applyFilter(value){
    this.employeesList.filter = value.trim().toLowerCase()

  }
  ngAfterViewInit() {
    this.employeesList.paginator = this.paginator;
    this.employeesList.sort = this.sort;
  }
}
