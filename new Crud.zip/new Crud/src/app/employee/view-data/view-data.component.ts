import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-view-data',
  templateUrl: './view-data.component.html',
  styleUrls: ['./view-data.component.css']
})
export class ViewDataComponent implements OnInit {

  employeeDetails:any ={id:'',name:'',country:''}
  constructor(private _ar:ActivatedRoute) {
    this._ar.paramMap.subscribe(params=>{
      this.employeeDetails = JSON.parse(atob(params['params']['data']))
     // console.log(this.employeeDetails)
    })
   }

  ngOnInit(): void {
  }

}
