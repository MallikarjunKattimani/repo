import { Component, OnInit } from '@angular/core';
import { AbstractControl, FormArray, FormBuilder, FormControl, FormGroup, ValidatorFn, Validators } from '@angular/forms';
import { Router } from '@angular/router';
//import { timeStamp } from 'console';
import { EmployeeService } from '../employee/employee.service';

@Component({
  selector: 'app-create',
  templateUrl: './create.component.html',
  styleUrls: ['./create.component.css']
})
export class CreateComponent implements OnInit {
  employeeForm: FormGroup
  imagePreview
  fileSizeError
  fileFormateError
  files=[]
  file =''
  fileTypes=[]
  fileSize=null
  fileSizes=[]
  constructor(private _service: EmployeeService, private router: Router,private fb :FormBuilder) { }
  ngOnInit(): void {
    this.employeeForm = new FormGroup({
      id: new FormControl(''),
      name: new FormControl('', [Validators.required]),
      country: new FormControl('', [Validators.required,Validators.minLength(3)]),
      files: new FormControl('', [Validators.required,]),
      // multiple: new FormControl([], [Validators.required,this.fileSizeValidator(500),this.fileFormateValidator('pdf,txt')])
    })
  }
  onImagePicked(event) {
    const file = event.target.files[0];
    const name= file.name
   this.fileSize = this.bytesToSize(file.size)
   console.log(this.fileSize)
   this.file=file.name
   this.employeeForm.patchValue({files:file.name})
   this.employeeForm.updateValueAndValidity()
   console.log(this.fileSizeValidator)
   this.fileSizeValidator
   //this.fileSizes.push(this.bytesToSize(file.size))
    const reader = new FileReader();
    reader.onload = () => {
      this.imagePreview = reader.result;
    };
    reader.readAsDataURL(file);
  }
  onSubmit() {
    console.log('called')
    this.employeeForm.get('files')
    if (this.employeeForm.valid) {
     const formData= new FormData()
      formData.append('files','hi.mpg')
   
      this.employeeForm.value['file']= this.file; 
      delete this.employeeForm.value.files;
      formData.append('value',JSON.stringify(this.employeeForm.value));
     formData.forEach(element => {
      //console.log(element)
      })
      console.log(this.employeeForm.value)
      this._service.saveEmployee(this.employeeForm.value)
      this.employeeForm.reset()
    }
  }
  bytesToSize(bytes) {
    const sizes = ['Bytes', 'KB', 'MB', 'GB', 'TB'];
    if (bytes === 0) return 'n/a';
    const i = Number(Math.floor(Math.log(Math.abs(bytes)) / Math.log(1024)));
    if (i === 0) return `${bytes} ${sizes[i]})`;
    console.log(i)
    return `${(bytes / (1024 ** i)).toFixed(1)}${sizes[i]}`;
  }
  back() {
    this.router.navigate(['/employee'])
  }

//   fileFormateValidator(control:AbstractControl):{[key:string]:boolean} | null{
//     const res = control.value
    
// };

  // fileSizeValidator(control:AbstractControl): { [key: string]: boolean } | null {
  // if( control.value!=''){
  //   const bytes=control.value.size
  //   const sizes = ['Bytes', 'KB', 'MB', 'GB', 'TB'];
  //   const i = Number(Math.floor(Math.log(Math.abs(bytes)) / Math.log(1024)))
  //   //console.log(i)
  //   const size =  Number((bytes / (1024 ** i)).toFixed(1));
  //   console.log(typeof(size))
  //     if(size <=  50){
  //     return null
  //     }
  //   return {fileSizeValidator:true}
  //  }
  //  return null
  // }

  fileSizeValidator(value): ValidatorFn {
   return (control:AbstractControl): { [key: string]: boolean } | null =>
   {
     if(control.value!= ''){
      const bytes=control.value.size
      const sizes = ['Bytes', 'KB', 'MB', 'GB', 'TB'];
      const i = Number(Math.floor(Math.log(Math.abs(bytes)) / Math.log(1024)))
      //console.log(i)
      const size =  Number((bytes / (1024 ** i)).toFixed(1));
      console.log(typeof(size))
        if(size <=  value){
        return null
        }
      return {fileSizeValidator:true}
     }}
    }

    fileFormateValidator(value):ValidatorFn {
      return (control:AbstractControl): { [key: string]: boolean } | null =>
      {
        if(control.value!= ''){
          const file = control.value as FormArray
          //console.log(file.push( 'control.value'))
        const formate = (control.value.name.substring(control.value.name.lastIndexOf('.') + 1)).toLowerCase();
        console.log(formate)
         const arr=value.split(',')
         console.log(arr)
       let valid:boolean
         for (var i = 0; i <  arr.length; i++) {
          if (formate == arr[i]) {
           valid=true
           break
          } else {
           valid= false
          }
        }
          return valid ?null: {fileFormateValidator:true}
         //return {fileSizeValidator:true}
        }
        return null
      }
   }

   onFilesPicked(event){
     const files =event.target.files
    for (let j = 0; j < files.length; j++) {
     
      let fArray = this.employeeForm.get('multiple') as FormArray
          fArray.push(this.fb.group({multiple:files[j]}))
          console.log(this.employeeForm.get('multiple'))
    }
   }
}


  function fileFormateValidator(value):ValidatorFn {
    return (control:AbstractControl): { [key: string]: boolean } | null =>
    {
      if(control.value!= ''){
      const formate = (control.value.name.substring(control.value.name.lastIndexOf('.') + 1)).toLowerCase();
      console.log(formate)
       const arr=value.split(',')
       console.log(arr)
     let valid:boolean
       for (var i = 0; i <  arr.length; i++) {
        if (formate == arr[i]) {
         valid=true
         break
        } else {
         valid= false
        }
      }
        return valid ?null: {fileFormateValidator:true}
       return {fileSizeValidator:true}
      }
      return null
    }
 }
