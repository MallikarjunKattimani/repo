import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
//import employee from '../../assets/employee.json'
const  employee=[
  {"id":1,"name":"john","country":"france","file":"rose.png"},
  {"id":2,"name":"robert","country":"india","file":"mi2.png"},
  {"id":3,"name":"mike","country":"japan","file":"myimage.png"}
]
@Injectable({
  providedIn: 'root'
})
export class EmployeeService {
  data: any = []
  constructor() { }
  getEmployeesList(): Observable<any> {
    this.data = employee
    return this.data
  }
  saveEmployee(params): Observable<any> {
    //debugger
    this.data = employee
    let i = this.data.length - 1
    if (this.data.length > 0) {
      params.id = this.data[i].id + 1
      console.log(params.files)
      this.data.push(params)
      return this.data
    }
    else {
      params.id = 1
      this.data.push(params)
      return this.data
    }
  }
  updateEmployee(params): Observable<any> {
    this.data = employee
    let index = this.data.findIndex((x) => x.id == params.id);
    this.data = this.data.splice(index, 1, params);
    return this.data;
  }
  deleteEmployee(id): Observable<any> {
    this.data = employee
    let index = this.data.findIndex((x) => x.id == id);
    this.data = this.data.splice(index, 1);
    return this.data;
  }
}
