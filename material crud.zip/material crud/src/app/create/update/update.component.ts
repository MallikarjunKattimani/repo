import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { EmployeeService } from '../../employee/employee.service';

@Component({
  selector: 'app-update',
  templateUrl: '../create.component.html', 
  styleUrls: ['./update.component.css']
})
export class UpdateComponent implements OnInit {
employeeDetails
  employeeForm:FormGroup
  constructor(private router:Router,private _service:EmployeeService,private _ar:ActivatedRoute) {
    this._ar.paramMap.subscribe(params=>{
      this.employeeDetails = JSON.parse(atob(params['params']['body']))
      console.log(this.employeeDetails)
    })
   }

  ngOnInit(): void {
    this.employeeForm= new FormGroup({
      id:new FormControl(''),
      name:new FormControl('',[Validators.required]),
      country:new FormControl('',[Validators.required])
    })
   this.employeeForm.patchValue(this.employeeDetails)
  }

  onSubmit(){
if(this.employeeForm.valid){
  this.employeeForm.get('id').setValue(this.employeeDetails.id)
  //console.log(this.employeeForm)
  this._service.updateEmployee(this.employeeForm.value)
  this.employeeForm.reset()
}

  }
  back(){
    this.router.navigate(['/employee'])
  }
}
