import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Subject } from 'rxjs';

interface Department {
  id,
  departmentName:string,
  discreptions:string
}

@Injectable({
  providedIn: 'root'
})
export class DepartmentsService {
 
  private _url =  'api/departments'
message= null
  constructor(private http: HttpClient) { }

  private user: Department[] = [];
  private updateUser = new Subject<Department[]>();

  addUser(dep) {
    const user  = { departmentName:dep.departmentName,discreptions:dep.discreptions };
    return this.http.post<any>(this._url, user).subscribe((resp => {
      this.getUsers()
    }), error => {
      //this.errorHand(error);
      this.message=error 
      console.log(error)
    })
  }

  updateUserListener() {
    return this.updateUser.asObservable();
  }
  getUsers() {
    this.http
      .get<any>(
        this._url
      )
      .subscribe((transformedPosts => {
        this.user = transformedPosts;
        console.log(this.user)
        this.updateUser.next([...this.user]);
      }), error => {
        //this.errorHand(error);
        this.message=error 
        console.log(error)
      });
  }

  deleteUser(usersId) {
    this.http.delete(this._url + '/' + usersId)
      .subscribe((() => {
        this.getUsers()
      }), error => {
        //this.errorHand(error);
        this.message=error 
        console.log(error)
      });
  }
  editUser(dep: any,id) {
    console.log(id)
    const user1:Department = { id:id,departmentName:dep.departmentName,discreptions:dep.discreptions}
    console.log(user1);
    this.http.put(this._url + '/' + id, user1).subscribe((res => {
      this.getUsers()
    }), error => {
     // this.errorHand(error);
     this.message=error 
      console.log(error)
    })
  }
}
