import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import { MatDialog } from '@angular/material/dialog';
import { ModalDismissReasons, NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { ToastrService } from 'ngx-toastr';
import { Subscription } from 'rxjs';
import { DepartmentsService } from './departments.service';
@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {
  isChecked:any= {}
  closeResult: string;
  departments = []
  userSub: Subscription;
  isNew:boolean
  departmentHeading
  deletingDepartment
  name
  errorMsg
  constructor(private depS:DepartmentsService, 
    private dialog: MatDialog,
    private fb:FormBuilder,
    private modalService: NgbModal,
    private toastr: ToastrService) { }
   
    myForm=this.fb.group({
      id:[null],
      departmentName:['',Validators.required,],
      discreptions:['',Validators.required,]
     })

  ngOnInit() {
    this.depS.getUsers();
    this.userSub = this.depS.updateUserListener().subscribe((user) => {
      this.departments = user
      console.log(this.departments)
    })
    // console.log('OnInit called')
  }

onSubmit(){

 const  delail={  departmentName:'xcvb',discreptions:'zxcvb' }
  if(this.isNew){
    this.depS.addUser(delail);
    this.myForm.reset();
this.errorMsg=this.depS.message
    if(this.errorMsg){
       
    }
    else{
     // this.toastr.success('department created', 'Success');
    }
  }
  else{
    this.depS.editUser(this.myForm.value,this.myForm.get('id').value)
    this.myForm.reset();
    if(this.depS.message =!null){
      this.toastr.error(this.depS.message, 'Error')
    }
    else{
    this.toastr.success('department updated', 'Success');
    }
  }
  this.modalService.dismissAll()
  this.depS.message=null
}

openDelete(deleteConfirm, department){
  this.deletingDepartment=department
  this.modalService.open(deleteConfirm, {ariaLabelledBy: 'modal-basic-title'}).result.then((result) => {
    this.closeResult = `Closed with: ${result}`;
  }, (reason) => {
    this.closeResult = `Dismissed ${this.getDismissReason(reason)}`;
  });
}


onDeleteConfirmation() {
this.depS.deleteUser(this.deletingDepartment.id)
      this.modalService.dismissAll("on fail");
     // this.toastr.success('School Deleted', 'Success');
}
  open(content, type:boolean,department?) {
    this.isNew=type
    this.departmentHeading =this.isNew? 'add your department details':'edit your department details';
    this.name=this.isNew?'save':'update'
    if( this.isNew){
      this.myForm.reset()
    }
else{
  this.myForm.patchValue(department,{ onlySelf:true})
}
    this.modalService.open(content, {ariaLabelledBy: 'modal-basic-title'}).result.then((result) => {
      this.closeResult = `Closed with: ${result}`;
    }, (reason) => {
      this.closeResult = `Dismissed ${this.getDismissReason(reason)}`;
    });
  }

  private getDismissReason(reason: any): string {
    if (reason === ModalDismissReasons.ESC) {
      return 'by pressing ESC';
    } else if (reason === ModalDismissReasons.BACKDROP_CLICK) {
      return 'by clicking on a backdrop';
    } else {
      return `with: ${reason}`;
    }
  }
  checked(i){
this.isChecked[i]=!this.isChecked[i]
  }




  ngOnDestroy() {
    this.userSub.unsubscribe();
  }
}
