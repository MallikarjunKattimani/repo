import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { EmployeeService } from '../employee/employee.service';

@Component({
  selector: 'app-create',
  templateUrl: './create.component.html',
  styleUrls: ['./create.component.css']
})
export class CreateComponent implements OnInit {
employeeForm:FormGroup
  constructor(private _service:EmployeeService,private router:Router) { }

  ngOnInit(): void {
    this.employeeForm= new FormGroup({
      id:new FormControl(''),
      name:new FormControl('',[Validators.required]),
      country:new FormControl('',[Validators.required])
    })
  }

  onSubmit(){
    console.log('called')
    if(this.employeeForm.valid){
      this._service.saveEmployee(this.employeeForm.value)
      this.employeeForm.reset()
    }
  }
  back(){
    this.router.navigate(['/employee'])
  }
}
