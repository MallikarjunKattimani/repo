import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit {
  title = 'hrnew';
  login:any
  user
  constructor( private router:Router){
    this.loggedIn()
  }
  ngOnInit(){
this.loggedIn()
  }
  logout(){
    localStorage.clear()
    this.login=false
    this.router.navigate(['/login'])
  }

  loggedIn(){
    if(localStorage.getItem('user')){
      this.login=true
      this.user=localStorage.getItem('user')
      return true
    }
    else{
      this.login=false
      return false
     // this.logout()
    }
  }
}
 