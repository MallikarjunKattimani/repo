import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { EmployeeService } from '../../employee/employee.service';

@Component({
  selector: 'app-update',
  templateUrl: '../create.component.html', 
  styleUrls: ['./update.component.css']
})
export class UpdateComponent implements OnInit {
employeeDetails
imagePreview
  employeeForm:FormGroup
  constructor(private router:Router,private _service:EmployeeService,private _ar:ActivatedRoute) {
    this._ar.paramMap.subscribe(params=>{
      this.employeeDetails = JSON.parse(atob(params['params']['body']))
      console.log(this.employeeDetails)
    })
   }

  ngOnInit(): void {
    this.employeeForm= new FormGroup({
      id:new FormControl(''),
      name:new FormControl('',[Validators.required]),
      country:new FormControl('',[Validators.required]),
      file: new FormControl('', [Validators.required])
    })
    this.employeeForm.patchValue(this.employeeDetails)
  }
  onImagePicked(event: Event) {
    const file = (event.target as HTMLInputElement).files[0];
    const name= file.name
    this.employeeForm.patchValue({ file: file.name });
    this.employeeForm.get("file").updateValueAndValidity();
    console.log(file)
    const reader = new FileReader();
    reader.onload = () => {
      this.imagePreview = reader.result;
      console.log(file)
    };
    reader.readAsDataURL(file);
  }
  onSubmit(){
if(this.employeeForm.valid){
  this.employeeForm.get('id').setValue(this.employeeDetails.id)
  //console.log(this.employeeForm)
  this._service.updateEmployee(this.employeeForm.value)
  this.employeeForm.reset()
}

  }
  back(){
    this.router.navigate(['/employee'])
  }
}
