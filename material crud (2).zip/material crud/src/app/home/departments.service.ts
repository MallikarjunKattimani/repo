import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class DepartmentsService {
  url: string = 'api/departments'
  constructor(private http: HttpClient) { }
  getDepartmentList() {
    return this.http.get(this.url);
  }

  saveDepartment(department: any) {
    return this.http.post(this.url, department);
  }

  updateDepartment(department: any, id: any) {
    return this.http.put(this.url+'/' + id, department);
  }

  deleteDepartment(id: any) {
    return this.http.delete(this.url+'/' + id);
  }
}
