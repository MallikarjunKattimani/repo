import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { MatDialog } from '@angular/material/dialog';
import { ModalDismissReasons, NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { DepartmentsService } from './departments.service';
@Component({
  selector: 'app-home',
  
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {
  departmentForm : FormGroup;
  closeResult : any;
 
  departmentHeading
  deletingDepartment:any
  isNew
  name
  submitted : boolean = false;
  departments:any=[]
  isChecked:any= {}
  constructor(private _service:DepartmentsService,
              public dialog: MatDialog,
              private modalService: NgbModal) { }

  ngOnInit(): void {
    this.departmentForm = new FormGroup({
      id : new FormControl(''),
      departmentName : new FormControl('', [Validators.required]),
      discreptions : new FormControl('', [Validators.required])
    });
    this.getAllDepartments();
  }

  getAllDepartments() {
    this._service.getDepartmentList().subscribe(
      data => {
        this.departments = data
        console.log( this.departments)
      },
      error => {
      });
  }
  getDepartmentId(){
    if(this.departmentForm.value.id)
      return this.departmentForm.value.id;
    else return 0;
  }
  /** 
   * Create ot update department 
  */
  onSubmit(){
    this.dialog.closeAll();
    if(this.departmentForm.valid){
      this.submitted = true;
      if(this.getDepartmentId()>0){
        this._service.updateDepartment(this.departmentForm.value,this.getDepartmentId()).subscribe(data => {
          console.log(data);
        });
      }else{
        // create API call
        delete this.departmentForm.value.id;
        this._service.saveDepartment(this.departmentForm.value).subscribe(data => {
          console.log(data);
        });
      }
      this.getAllDepartments();
    }else{
      this.submitted = false;
    }
    this.modalService.dismissAll()
  }
  open(content, type: boolean, department?) {
    this.isNew=type
    this.departmentHeading =this.isNew? 'add your department details':'edit your department details';
    this.name=this.isNew?'save':'update'
    if( this.isNew){
      this.departmentForm.reset()
    }
else{
  this.departmentForm.patchValue(department,{ onlySelf:true})
}
    this.modalService.open(content, {ariaLabelledBy: 'modal-basic-title'}).result.then((result) => {
      this.closeResult = `Closed with: ${result}`;
    }, (reason) => {
      this.closeResult = `Dismissed ${this.getDismissReason(reason)}`;
    });
  }
  openDelete(deleteConfirm, department){
    this.deletingDepartment=department
    this.modalService.open(deleteConfirm, {ariaLabelledBy: 'modal-basic-title'}).result.then((result) => {
      this.closeResult = `Closed with: ${result}`;
    }, (reason) => {
      this.closeResult = `Dismissed ${this.getDismissReason(reason)}`;
    });
  }
  

  onDeleteConfirmation() {
    this._service.deleteDepartment(this.deletingDepartment.id).subscribe(
      (data: any) => {
        this.getAllDepartments();
        this.modalService.dismissAll("on fail");
      },
      (error: any) => {
        console.log(error);
        this.modalService.dismissAll("on fail");
      }
    );
  }

  private getDismissReason(reason: any): string {
    if (reason === ModalDismissReasons.ESC) {
      return "by pressing ESC";
    } else if (reason === ModalDismissReasons.BACKDROP_CLICK) {
      return "by clicking on a backdrop";
    } else {
      return `with: ${reason}`;
    }
  }
}
