import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { HomeComponent } from './home/home.component';
import { InMemoryWebApiModule } from 'angular-in-memory-web-api';
import { DepartmentsDataListService } from './departments-data-list.service';
import { HttpClientModule } from '@angular/common/http';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { MatDialogModule } from '@angular/material/dialog';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { ToastrModule } from 'ngx-toastr';
import { EmployeeComponent } from './employee/employee.component';
import {MatPaginatorModule} from '@angular/material/paginator';
import {MatTableModule} from '@angular/material/table';
import { MatSortModule } from '@angular/material/sort';
import {MatFormFieldModule} from '@angular/material/form-field';
import { MatButton, MatButtonModule } from '@angular/material/button';
import {MatInputModule} from '@angular/material/input';
import { MatExpansionModule } from '@angular/material/expansion';
import {MatCardModule} from '@angular/material/card';
import { LoginComponent } from './login/login.component';
import { ListComponent } from './list/list.component';
import { ViewDataComponent } from './employee/view-data/view-data.component';
import {MatRadioModule} from '@angular/material/radio';
import {MatCheckboxModule} from '@angular/material/checkbox';
import {MatSelectModule} from '@angular/material/select';
import {MatDatepickerModule} from '@angular/material/datepicker';
import {MatNativeDateModule} from '@angular/material/core';
 import { MatMomentDateModule } from "@angular/material-moment-adapter";
@NgModule({  
  declarations: [
    AppComponent,
    HomeComponent,
    EmployeeComponent,
    LoginComponent,
    ListComponent,
    ViewDataComponent
  ], 
  imports: [
    BrowserModule,
    AppRoutingModule, 
    HttpClientModule,
    FormsModule,
    ReactiveFormsModule,MatDatepickerModule,
    MatDialogModule,MatSelectModule, 
    MatButtonModule,MatCheckboxModule,MatNativeDateModule,
    MatFormFieldModule, 
    MatTableModule,
    MatInputModule,
    MatPaginatorModule,
    MatSortModule,MatRadioModule,
    MatExpansionModule,
    MatCardModule,MatNativeDateModule,MatMomentDateModule,
    InMemoryWebApiModule.forRoot(DepartmentsDataListService),
    BrowserAnimationsModule,
    ToastrModule.forRoot(),
    NgbModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
 