import { AfterViewInit, Component, OnInit, ViewChild } from '@angular/core';
import { MatPaginator } from '@angular/material/paginator';
import { MatTableDataSource } from '@angular/material/table';
import { Router } from '@angular/router';
import { EmployeeService } from './employee.service';
import { MatSort } from '@angular/material/sort';

@Component({
  selector: 'app-employee',
  templateUrl: './employee.component.html',
  styleUrls: ['./employee.component.css']
})
export class EmployeeComponent implements OnInit, AfterViewInit {
  employeesList =new MatTableDataSource()
  @ViewChild(MatPaginator) paginator: MatPaginator;
  @ViewChild(MatSort) sort: MatSort;
  pageIndex = 0;
  pageSize = 2;
  totalRecords = 0;
  displayedColumns: string[] = ['id','name', 'country','file', 'action'];
  //dataSource = new MatTableDataSource();
  constructor(private _service: EmployeeService, private router: Router) { }

  ngOnInit(): void {
    this.getDetails()
    //console.log(this.dataSource)
  }
  getDetails() {
    const data:any = this._service. getEmployeesList()
    this.employeesList = new MatTableDataSource(data)
    console.log(this.employeesList)
  }

  open(type?, content?) {
    if (type) {
      console.log('hi')
      this.router.navigate(['/create'])
    }
    else {
      let data = JSON.stringify(content)
      console.log(data)
      this.router.navigate(['update', btoa(data)])
    }
  }
  openDelete(data) {
    this._service.deleteEmployee(data.id)
    this.getDetails()
  }
  applyFilter(value){
    this.employeesList.filter = value.trim().toLowerCase()

  }
  ngAfterViewInit() {
    this.employeesList.paginator = this.paginator;
    this.employeesList.sort = this.sort;
  }
}
