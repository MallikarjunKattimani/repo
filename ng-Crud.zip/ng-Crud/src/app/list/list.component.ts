import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';



const employees=[
  {"id":1, "name":"Arjun", "country":"India"},
  {"id":2, "name":"Paulson", "country":"America"},
  {"id":3, "name":"Karan", "country":"India"},
  {"id":4, "name":"Randy Orton", "country":"Japan"},
  {"id":5, "name":"Batista", "country":"USA"}
]
@Component({
  selector: 'app-list',
  templateUrl: './list.component.html',
  styleUrls: ['./list.component.css']
})
export class ListComponent implements OnInit {
  employeeForm:FormGroup
  employees:any = employees
   employDetails:any={id:'',name:'',country:''}

  constructor() { }

  ngOnInit(): void {
    this.employeeForm = new FormGroup({
      id: new FormControl(''),
      name: new FormControl('', [Validators.required]),
      country: new FormControl('', [Validators.required,Validators.minLength(3)])
    })
  }

  add(){}
  onSubmit(){
    if(this.employeeForm.valid){
      const params =this.employeeForm.value
      let i = this.employees.length - 1
      console.log(this.employees.length)
      if (this.employees.length > 0) {
        params.id = this.employees[i].id + 1
        this.employees.push(params)
        this.employees
      }
      else {
        params['id'] = 1
        this.employees.push(params)
        this.employees
      }
      this.employeeForm.reset()
      console.log(this.employees)
    }
  }

delete(id){
  //this.employees = employees
  this.employees = this.employees.filter((x) => x.id != id); 
  console.log(this.employees)
}
openModel(data){
  this.employDetails=data
}
}
