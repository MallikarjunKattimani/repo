import { AfterViewInit, Component, OnInit, ViewChild } from '@angular/core';
import { MatPaginator } from '@angular/material/paginator';
import { MatTableDataSource } from '@angular/material/table';
import { Router } from '@angular/router';
import { EmployeeService } from './employee.service';
import { MatSort } from '@angular/material/sort';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { DateAdapter, MAT_DATE_FORMATS, MAT_DATE_LOCALE } from '@angular/material/core';
@Component({
  selector: 'app-employee',
  templateUrl: './employee.component.html',
  styleUrls: ['./employee.component.css'] 
  
})
export class EmployeeComponent implements OnInit, AfterViewInit {
  employeesList =new MatTableDataSource()
  @ViewChild(MatPaginator) paginator: MatPaginator;
  @ViewChild(MatSort) sort: MatSort;
  myFile:any
  myFiles: any = [];
  maxDate = new Date();
  imagePreview
  fileTypes=["image/jpeg",
  "image/png",
  "application/pdf",
  "application/vnd.openxmlformats-officedocument.wordprocessingml.document"
]
  pageIndex = 0;
  pageSize = 10;
  totalRecords = 0;
  employeeForm:FormGroup
  formOpen=false
  genders=['male','female','others']
  bloodGroup: any = [
    { label: 'A +ve', value: 'A+ve' },
    { label: 'A -ve', value: 'A-ve' },
    { label: 'B +ve', value: 'B+ve' },
    { label: 'B -ve', value: 'B-ve' },
    { label: 'AB +ve', value: 'AB+ve' },
    { label: 'AB -ve', value: 'AB-ve' },
    { label: 'O +ve', value: 'O+ve' },
    { label: 'O -ve', value: 'O-ve' },
    { label: 'Other', value: 'other' },
  ];
  displayedColumns: string[] = ['id','name', 'gender','address','areYouAdult','dateOfBirth',
  'bloodGroup','image','file',  'action']; 
  constructor(private _service: EmployeeService, private router: Router) { }

  ngOnInit(): void {
    this.getDetails()
    this.employeeForm = new FormGroup({
      id: new FormControl(''),
      name: new FormControl('', [Validators.required]),
      gender: new FormControl('', [Validators.required]),
      address:new FormControl('', [Validators.required]),
      areYouAdult:new FormControl('',),
      dateOfBirth:new FormControl('',),
      bloodGroup:new FormControl('', [Validators.required]),
      image:new FormControl('', [Validators.required]),
      file:new FormControl('', [Validators.required]),
      files:new FormControl('')
    }) 
  }
  getDetails() {
    const data:any = this._service. getEmployeesList()
    this.employeesList = new MatTableDataSource(data)
    //console.log(this.employeesList)
   
  }

  open(type?, content?) {
    this.formOpen=true
    if (type) { 
    this.employeeForm.reset() 
    }
    else { 
      this.employeeForm.patchValue(content) 
    }
  }
  getEmployeeId(){
    if(this.employeeForm.value.id) 
      return this.employeeForm.value.id
    else return 0
  }
  onSubmit() {
    if (this.employeeForm.valid) {
      console.log(this.employeeForm.value)
      if(this.getEmployeeId()>0){
      // let formData =new FormData()
      // formData.append('file',this.myFile.name)
      // formData.append('name',this.employeeForm.value.name)
      // formData.append('address',this.employeeForm.value.address)
      // formData.append('gender',this.employeeForm.value.gender)
      // formData.append('areYouAdult',this.employeeForm.value.areYouAdult)
      // formData.append('gender',this.employeeForm.value.gender)
       this._service.updateEmployee(this.employeeForm.value)
     }
     else{
       this._service.saveEmployee(this.employeeForm.value)
     }
     let data = JSON.stringify(this.employeeForm.value)
     this.router.navigate(['view',btoa(data)])
    this.employeeForm.reset()
    }
  }

  

  onImagePicked(event ) {
    const file = (event.target as HTMLInputElement).files[0];
    this.employeeForm.patchValue({ image: file.name });
    this.employeeForm.get("image").updateValueAndValidity();
    const reader = new FileReader();
    reader.onload = () => {
      this.imagePreview = reader.result as string;
    };
    reader.readAsDataURL(file);
  }

  onFilePicked(event){
    if (event.target.files.length > 0) {
      Object.keys(event.target.files).forEach(key => {
        if (this.fileTypes.indexOf(event.target.files[key].type) > -1) { 
           if(  ((event.target.files[key].size)/1024)<=500 ){
           //this.employeeForm.get('file').setValue(event.target.files[key])
          this.myFile = event.target.files[key];
          this.employeeForm.patchValue({ file: this.myFile.name });
         // console.log( this.employeeForm.get('file').value)
        }
        else{
          alert(`warning ${event.target.files[key].name} file uploaded too large`) 
        }
        }
        else {
           this.myFile = '';
          alert('warning No file uploaded or invalid file type!');
          this.employeeForm.patchValue({
           file: ''
          })
          return false;
        }
      });
    }
  }

  back(){
    this.formOpen=false
  }
  openDelete(data) {
    this._service.deleteEmployee(data.id)
    this.getDetails()
  }
  applyFilter(value){
    this.employeesList.filter = value.trim().toLowerCase()

  }
  ngAfterViewInit() {
    this.employeesList.paginator = this.paginator;
    this.employeesList.sort = this.sort;
  }

  onFileChange(event) {
    console.log(event.target.files);
    /*for (var i = 0; i < event.target.files.length; i++) {
      this.myFiles.push(event.target.files[i]);
    }*/
    if (event.target.files.length > 0) {
      Object.keys(event.target.files).forEach(key => {
        console.log(event.target.files[key].type);
        if (this.fileTypes.indexOf(event.target.files[key].type) > -1) {
          // event.target.files[key].sizeVal = this.bytesToSize(event.target.files[key].size);
          this.myFiles.push(event.target.files.name[key]);
          this.employeeForm.patchValue({
            files: this.myFiles
            // console.log(this.employeeForm.value.files)
          })
        }
        else {
          this.myFiles = [];
          alert(`'warning', 'No file uploaded or invalid file type!'`) 
 
          // this._toast.show('warning', 'No file uploaded or invalid file type!');
          this.employeeForm.patchValue({
            files: ''
          })
          return false;
        }
      });
    }
  }
}
