import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { AuthGuard } from './auth.guard';
import { EmployeeComponent } from './employee/employee.component';
import { ViewDataComponent } from './employee/view-data/view-data.component';
import { HomeComponent } from './home/home.component';
import { ListComponent } from './list/list.component';
import { LoginComponent } from './login/login.component';
 
const routes: Routes = [
  {path:'',redirectTo:"list",pathMatch:'full',canActivate:[AuthGuard]},
  {path:'login',component:LoginComponent},
  {path:'home',component:HomeComponent},
  {path:'view/:data',component:ViewDataComponent},
  {path:'employee',component:EmployeeComponent ,canActivate:[AuthGuard]},
  {path:'list',component:ListComponent,canActivate:[AuthGuard]} ,
    
]; 

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
