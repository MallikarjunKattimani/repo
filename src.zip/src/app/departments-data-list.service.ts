import { Injectable } from '@angular/core';
import { InMemoryDbService } from 'angular-in-memory-web-api';
@Injectable({
  providedIn: 'root'
})
export class DepartmentsDataListService implements InMemoryDbService {

  constructor() { }
  createDb() {
    let departments = [
      { id: 101, departmentName: 'Developing', discreptions: 'sdfg' },
      {
        id: 102, departmentName: 'Testing', discreptions: 'sdfg'
      },
      { id: 103, departmentName: 'back-end', discreptions: 'sdfg' }
    ]
    return { departments };
  }
}